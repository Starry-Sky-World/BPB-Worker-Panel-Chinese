<h1 align=“center”>💦 BPB面板</h1>

### 🌏 [波斯语](README_fa.md) [English](README.md)
![BPB-Worker-Panel-Chinese](https://socialify.git.ci/Starry-Sky-World/BPB-Worker-Panel-Chinese/image?description=1&descriptionEditable=BPB-Worker-Panel%E6%B1%89%E5%8C%96%E7%89%88%EF%BC%8C%E7%9B%AE%E5%89%8D%E9%83%A8%E5%88%86%E5%B8%A6%E6%9C%89BPB%E5%BC%80%E5%A4%B4%E7%9A%84vpn%E8%8A%82%E7%82%B9%E6%8F%90%E7%A4%BA%E5%9D%87%E5%B7%B2%E6%8D%A2%E6%88%90VPN%E5%BC%80%E5%A4%B4%E3%80%82%E6%B1%82Star!&font=Jost&forks=1&issues=1&language=1&logo=https%3A%2F%2Favatars.githubusercontent.com%2Fu%2F155004885%3Fv%3D4&name=1&owner=1&pulls=1&stargazers=1&theme=Auto)
<p align="center">
  <img src="docs/assets/images/Panel.jpg">
</p>
<br>

介绍
该项目致力于为开发用户面板[Cloudflare workers/pages代理脚本](https://github.com/yonggekkk/Cloudflare-workers-pages-vless)由[yong gekkk](https://github.com/yonggekkk)创建. 该面板提供了两个部署选项：
- **Cloudflare Worker**部署
- **Pages**部署
<br>


## 特点

1. **免费**：不涉及任何费用。
2. **用户友好面板：** 设计用于方便导航、配置和使用。
3. **支持片段：** 提供对片段功能的支持。
4. **屏蔽广告和色情（可选）**
5. **绕过伊朗和局域网（可选）**
6. **完整的路由规则：** 绕过伊朗，屏蔽广告，恶意软件，网络钓鱼...用于`Sing-Box`。
7. **链代理：** 可以添加一个`Chain Proxy`来修复IP。
8. **支持广泛的客户端：** 为`Xray`和单盒核心客户端提供订阅链接。
9. **订阅链接（JSON）：** 为JSON配置提供订阅链接。
10. **密码保护面板：** 使用密码保护保护面板。
11. **自定义Cloudflare Clean IP:** 能够使用在线扫描仪并设置干净的IP域。
12. **Warp配置：** 提供`Warp`和`Warp on Warp`订阅。
<br>

## 如何使用：
- [安装（Pages）](docs/Pages_Installation_fa.md)

- [安装（Worker）](docs/Worker_Installation_fa.md)

- [如何使用](docs/configuration_fa.md)

- [常见问题解答](docs/FAQ.md)
<br>

## 支持的客户端
|客户端|版本|是否可用|
| :-------------: | :-------------: | :-------------: |
| **v2rayNG**  | 1.8.19 or higher  | :heavy_check_mark: |
| **v2rayN**  | 6.42 or higher  | :heavy_check_mark: |
| **Nekobox**  |   | :x: |
| **Sing-box**  | 1.8.10 or higher  | :x: |
| **Streisand**  |   | :heavy_check_mark: |
| **V2Box**  |   | :x: |
| **Shadowrocket**  |   | :x: |
| **Nekoray**  |   | :heavy_check_mark: |
| **Hiddify**  |   | :x: |


---

---

### 特别感谢
- CF vless代码作者[3Kmfi6HP](https://github.com/3Kmfi6HP/EDtunnel)
- CF 首选IP程序作者[badafans](https://github.com/badafans/Cloudflare-IP-SpeedTest)，[XIU2](https://github.com/XIU2/CloudflareSpeedTest)
- [BPB Worker Panel](https://github.com/bia-pain-bache/BPB-Worker-Panel)官方版

---
